<?php 
session_start();
?>
<html>
<HEAD>
	<title>Suggestion</title>
</HEAD>
<body>

<div id="header_bg"></div>

<?php

include '../Scripts/global.php';

include 'header.php';

?>

<div id="wrapper">

<div id="content">
<h1>Suggestion</h1>
</div>
</div>

<?php
	include './footer.php';
?>

</body>
</html>