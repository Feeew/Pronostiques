<?php 
session_start();
?>
<html>
<HEAD>
	<title>Contact</title>
</HEAD>
<body>

<div id="header_bg"></div>

<?php

include '../Scripts/global.php';

include 'header.php';

?>

<div id="wrapper">

<div id="content">
<h1>Me contacter</h1>
</div>
</div>

<?php
	include './footer.php';
?>

</body>
</html>